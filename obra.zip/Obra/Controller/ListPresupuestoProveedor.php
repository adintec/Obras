<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2017-2019 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
namespace FacturaScripts\Plugins\Obra\Controller;

use FacturaScripts\Core\Controller\ListPresupuestoProveedor as ParentController;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
/**
 * Controller to list the items in the PresupuestoProveedor model
 *
 * @author Carlos García Gómez          <carlos@facturascripts.com>
 * @author Artex Trading sa             <jcuello@artextrading.com>
 * @author Raul Jimenez                 <raul.jimenez@nazcanetworks.com>
 * @author Cristo M. Estévez Hernández  <cristom.estevez@gmail.com>
 * @author Alicia Afonso González       <alicia@adintec.es>
 * 
 */

class ListPresupuestoProveedor extends ParentController
{
    protected function createViews($viewName = 'ListPresupuestoProveedor', $model = 'PresupuestoProveedor', $label = 'estimations')
    {
        
        $this->addView($viewName, $model, $label, 'fas fa-copy');
        $this->addSearchFields($viewName, ['codigo', 'numproveedor', 'observaciones']);
        $this->addOrderBy($viewName, ['codigo'], 'code');
        $this->addOrderBy($viewName, ['fecha', 'hora', 'codigo'], 'date', 2);
        $this->addOrderBy($viewName, ['numero'], 'number');
        $this->addOrderBy($viewName, ['numproveedor'], 'numsupplier');
        $this->addOrderBy($viewName, ['total'], 'amount');

        /// filters
        $this->addFilterPeriod($viewName, 'date', 'period', 'fecha');
        $this->addFilterNumber($viewName, 'min-total', 'total', 'total', '>=');
        $this->addFilterNumber($viewName, 'max-total', 'total', 'total', '<=');

        $where = [new DataBaseWhere('tipodoc', $model)];
        $statusValues = $this->codeModel->all('estados_documentos', 'idestado', 'nombre', true, $where);
        $this->addFilterSelect($viewName, 'idestado', 'state', 'idestado', $statusValues);

        $users = $this->codeModel->all('users', 'nick', 'nick');
        if (count($users) > 2) {
            $this->addFilterSelect($viewName, 'nick', 'user', 'nick', $users);
        }

        $companies = $this->codeModel->all('empresas', 'idempresa', 'nombrecorto');
        if (count($companies) > 2) {
            $this->addFilterSelect($viewName, 'idempresa', 'company', 'idempresa', $companies);
        }

        $warehouseValues = $this->codeModel->all('almacenes', 'codalmacen', 'nombre');
        if (count($warehouseValues) > 2) {
            $this->addFilterSelect($viewName, 'codalmacen', 'warehouse', 'codalmacen', $warehouseValues);
        }

        $serieValues = $this->codeModel->all('series', 'codserie', 'descripcion');
        if (count($serieValues) > 2) {
            $this->addFilterSelect($viewName, 'codserie', 'series', 'codserie', $serieValues);
        }

        $paymentValues = $this->codeModel->all('formaspago', 'codpago', 'descripcion');
        $this->addFilterSelect($viewName, 'codpago', 'payment-method', 'codpago', $paymentValues);
        
        $this->addFilterAutocomplete($viewName, 'codproveedor', 'supplier', 'codproveedor', 'Proveedor');
        //$this->addFilterCheckbox($viewName, 'femail', 'email-not-sent', 'femail', 'IS', null);
        
        $obras = $this->codeModel->all('obras', 'codobra', 'descripcion');
        $this->addFilterSelect($viewName, 'codobra','work', 'codobra', $obras);
        $this->addButtonGroupDocument($viewName);
        $this->addButtonApproveDocument($viewName);
	
        $this->createViewLines('ListLineaPresupuestoProveedor', 'LineaPresupuestoProveedor');

    }
}