<?php
/**
 * This file is part of FacturaScripts
 * Copyright (C) 2017-2019 Carlos Garcia Gomez <carlos@facturascripts.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
namespace FacturaScripts\Plugins\Obra\Controller;

use FacturaScripts\Core\Lib\ExtendedController\EditController;
use FacturaScripts\Core\Base\DataBase\DataBaseWhere;
/**
 * Controller to edit Obra.
 *
 * @author Alicia Afonso González        <alicia@adintec.es>
 *
 */
class EditObra extends EditController 
{
    public function getModelClassName() {
        return 'Obra';
    }
    public function getPageData()
    {
        $pageData = parent::getPageData();
        $pageData['menu'] = 'purchases';
        $pageData['title'] = 'works';
        $pageData['icon'] = 'fas fa-pallet';

        return $pageData;
    }
    protected function createViews()
    {
       parent::createViews();
       $this->addListView('ListAlbaranProveedor', 'AlbaranProveedor','delivery-notes', 'fas fa-copy');
       $this->addListView('ListFacturaProveedor', 'FacturaProveedor','invoices', 'fas fa-copy');
       $this->addListView('ListPresupuestoProveedor', 'PresupuestoProveedor','estimations', 'fas fa-copy');
       $this->addListView('ListPedidoProveedor', 'PedidoProveedor','orders', 'fas fa-copy');
       $this->createLineView('ListLineaFacturaProveedor', 'LineaFacturaProveedor');
    }
    protected function createLineView($viewName, $model, $label = 'products')
    {
        $this->addListView($viewName, $model, $label, 'fas fa-cubes');

        /// sort options
        $this->views[$viewName]->addOrderBy(['idlinea'], 'code', 2);
        $this->views[$viewName]->addOrderBy(['cantidad'], 'quantity');
        $this->views[$viewName]->addOrderBy(['pvptotal'], 'amount');

        /// search columns
        $this->views[$viewName]->searchFields[] = 'referencia';
        $this->views[$viewName]->searchFields[] = 'descripcion';

        /// disable buttons
        $this->setSettings($viewName, 'btnDelete', false);
        $this->setSettings($viewName, 'btnNew', false);
    }
    
    protected function loadData($viewName, $view)
    {
       switch ($viewName) {
            case 'ListAlbaranProveedor':
            case 'ListFacturaProveedor':
            case 'ListPresupuestoProveedor':
            case 'ListPedidoProveedor':
               $codobra = $this->getViewModelValue('EditObra', 'codobra');
               $where = [new DataBaseWhere('codobra', $codobra)];
               $view->loadData('', $where);
               break;
           case 'ListLineaFacturaProveedor':
                $codobra = $this->getViewModelValue('EditObra', 'codobra');
                $inSQL = 'SELECT idfactura FROM facturasprov WHERE codobra = '  . $this->dataBase->var2str($codobra);
                $where = [new DataBaseWhere('idfactura', $inSQL, 'IN')];
                $view->loadData('', $where);
                break;
            default:
               parent::loadData($viewName, $view);
               break;
       }
    }
    
}
